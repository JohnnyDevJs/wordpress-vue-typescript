<?php
    /**
     * Footer 404 template
     *
     * @package sjp
     */
?>


<?php wp_footer();?>
</div>
</body>

</html>