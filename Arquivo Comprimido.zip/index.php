<?php
    /**
     * Main template file.
     *
     * @package sjp
     */

    get_header();

?>

<section id="page">
  <div class="container">
    <?php the_content();?>
  </div>
  </div>
</section>



<?php
get_footer();