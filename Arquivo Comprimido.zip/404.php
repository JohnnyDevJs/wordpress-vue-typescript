<?php
/**
 * Page 404
 *
 * @package sjp
 */

get_header( '404' );

get_template_part( 'template-parts/pages/content', '404' );

get_footer( '404' );
?>