<?php
    /**
     * Content Toggler Template.
     *
     * @package sjp
     */
?>

<button class="navbar-toggler" type="button" id="button-open-navbar">
  <span class="navbar-toggler-icon"></span>
</button>