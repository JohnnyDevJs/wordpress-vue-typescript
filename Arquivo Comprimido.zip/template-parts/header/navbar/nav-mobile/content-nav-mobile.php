<div id="nav-mobile" class="position-fixed top-0 h-100 w-100">
  <button id="close" class="position-absolute">
    <i class="fas fa-close"></i>
  </button>
  <?php
      get_template_part( 'template-parts/header/navbar/nav/content', 'nav' );
      get_template_part( 'template-parts/components/content', 'social' );
  ?>
</div>