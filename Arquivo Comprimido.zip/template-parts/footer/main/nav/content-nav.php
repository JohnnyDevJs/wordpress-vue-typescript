<?php
/**
 * Content Footer Nav Template.
 *
 * @package sjp
 */

wp_nav_menu( ['menu' => 'menu', 'container' => false, 'menu_id' => 'footer-menu', 'menu_class' => '', 'theme_location' => 'sjp-footer-menu'] );

?>