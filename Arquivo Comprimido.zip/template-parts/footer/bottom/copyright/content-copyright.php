<?php
    /**
     * Content Copyright Template.
     *
     * @package sjp
     */

?>

<p class="copyright mb-sm-0 mb-2 small text-white text-sm-start text-center"><?php echo sjp_copyright(); ?></p>