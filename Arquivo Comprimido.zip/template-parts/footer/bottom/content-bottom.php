<div class="footer-bottom py-3">
  <div class="container">
    <div class="row">
      <div class="col-12 col-md-8">
        <?php echo get_template_part( 'template-parts/footer/bottom/copyright/content', 'copyright' ); ?>

      </div>

      <div class="col-12 col-md-4 ">
        <p class="developer mb-0 text-white small text-sm-end text-center">Desenvolvido por <a class="text-light-red"
            href="">Johnny
            Silva</a>
        </p>
      </div>
    </div>
  </div>
</div>
</div>